package com.digniche.muntum.program.entity;

import com.digniche.muntum.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.time.LocalDateTime;
/**
 * 프로그램 엔티티
 */

@Entity
@Table(name= "programs")
@Getter
@NoArgsConstructor(access =  AccessLevel.PROTECTED)
public class Program extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(
            name = "id",
            columnDefinition = "BINARY(16)",
            nullable = false,
            updatable = false
    )
    private UUID id;

    @Column(nullable = false, length = 100)
    private String title;

    @Enumerated(EnumType.STRING) //Enum 이름을 DB 문자열로 저장
    @Column(name = "type", nullable = false, length = 20)
    private ProgramType programType;

    @Column(name = "tagline", nullable = false, length = 255)
    private String tagline;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String curation;

    @Column(name = "is_reserved", nullable = false)
    private boolean reserved = false;

    @Column(name = "is_free", nullable = false)
    private boolean free = true;

    @Column(length = 255)
    private String price;

    @Column(name = "venue_name", nullable = false, length = 100)
    private String venueName;

    @Column(name = "venue_meta", length = 255)
    private String venueMeta;

    @Column(nullable = false, length = 255)
    private String address;

    @Column(precision = 10, scale = 8)
    private BigDecimal latitude;

    @Column(precision = 11, scale = 8)
    private BigDecimal longitude;

    @Column(name = "official_url", length = 500)
    private String officialUrl;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Column(name = "operating_period_meta", length = 255)
    private String operatingPeriodMeta;

    @Column(name = "operating_hours", length = 500)
    private String operatingHours;

    @Column(name = "operating_hours_meta", length = 255)
    private String operatingHoursMeta;

    @Column(name = "inquiry_contact", length = 255)
    private String inquiryContact;

    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;

    @Column(
            name = "deleted_by",
            columnDefinition = "BINARY(16)"
    )
    private UUID deletedBy;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ProgramStatus status = ProgramStatus.ACTIVE;

    @Builder
    public Program(
            String title,
            ProgramType  programType,
            String tagline,
            String curation,
            Boolean reserved,
            Boolean free,
            String price,
            String venueName,
            String venueMeta,
            String address,
            BigDecimal latitude,
            BigDecimal longitude,
            String officialUrl,
            LocalDate startDate,
            LocalDate endDate,
            String operatingPeriodMeta,
            String operatingHours,
            String operatingHoursMeta,
            String inquiryContact
    ) {
        this.title = title;
        this.programType = programType;
        this.tagline = tagline;
        this.curation = curation;
        this.reserved = reserved;  // @NotNull + @Valid로 보장됨
        this.free = free; // 나머지 String/날짜 필드는 this.x = x 그대로
        this.price = price;
        this.venueName = venueName;
        this.venueMeta = venueMeta;
        this.address = address;
        this.latitude = latitude;
        this.longitude = longitude;
        this.officialUrl = officialUrl;
        this.startDate = startDate;
        this.endDate = endDate;
        this.operatingPeriodMeta = operatingPeriodMeta;
        this.operatingHours = operatingHours;
        this.operatingHoursMeta = operatingHoursMeta;
        this.inquiryContact = inquiryContact;
        this.status = ProgramStatus.ACTIVE;
    }

    /**
     * 프로그램 정보 수정 (PUT - 전체 교체)
     */
    public void update(
            String title,
            ProgramType programType,
            String tagline,
            String curation,
            Boolean reserved,
            Boolean free,
            String price,
            String venueName,
            String venueMeta,
            String address,
            String officialUrl,
            String operatingPeriodMeta,
            String operatingHours,
            String operatingHoursMeta,
            String inquiryContact
    ) {
        if (title != null) this.title = title;
        if (programType != null) this.programType = programType;
        if (tagline != null) this.tagline = tagline;
        if (curation != null) this.curation = curation;
        if (reserved != null) this.reserved = reserved;
        if (free != null) this.free = free;
        if (price != null) this.price = price;
        if (venueName != null) this.venueName = venueName;
        if (venueMeta != null) this.venueMeta = venueMeta;
        if (address != null) this.address = address;
        if (officialUrl != null) this.officialUrl = officialUrl;
        if (operatingPeriodMeta != null) this.operatingPeriodMeta = operatingPeriodMeta;
        if (operatingHours != null) this.operatingHours = operatingHours;
        if (operatingHoursMeta != null) this.operatingHoursMeta = operatingHoursMeta;
        if (inquiryContact != null) this.inquiryContact = inquiryContact;
    }


    public void updateStatus(ProgramStatus status) {
        this.status = status;
    }

    public void updateOperatingPeriod(List<LocalDate> dateList) {
        this.startDate = dateList.get(0);
        this.endDate = dateList.get(1);
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }
}

